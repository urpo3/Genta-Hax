g++ -std=c++17 -Ofast -pthread -o proxy_linux proxy/enet/callbacks.c proxy/enet/compress.c proxy/enet/host.c proxy/enet/list.c proxy/enet/packet.c proxy/enet/peer.c proxy/enet/protocol.c proxy/enet/unix.c proxy/enet/win32.c proxy/events.cpp proxy/gt.cpp proxy/http.cpp proxy/proxy.cpp proxy/sandbird/sandbird.c proxy/server.cpp proxy/utils.cpp

